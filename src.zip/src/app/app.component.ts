import { Component, ViewChild, ElementRef } from '@angular/core';
//import 'chartjs-plugin-annotation';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


export class AppComponent {

 csvData: string
 public  dt:any = [];
 public month = [];
   onFileLoad(fileLoadedEvent) {
   
      //document.write("hi there\n");
      const textFromFileLoaded = fileLoadedEvent.target.result;
      this.csvData = textFromFileLoaded;
        let allTextLines = this.csvData.split('\n');
        //let len:string = toString(allTextLines.length);
        //document.write((allTextLines.length.toString()));
        let headers = allTextLines[0].split(',');
        let lines = [];
        let x_axis = [];
        //let month = [];
      
        for (let i = 0; i < allTextLines.length; i++) {
            // split content based on comma
            let data = allTextLines[i].split(',');
            let series_name = data[0];
            //document.write(series_name);
            //document.write((data.length.toString()));
            for(let k=1; k<data.length;k++)
            {
              //document.write((data.length.toString()));
                var datapoint = data[k].split('|');
                //this.month.push(datapoint[0]);
                document.write(datapoint[0]);
                document.write(datapoint[1]);
              var dp = datapoint[1];
              //var int_dp = +dp;
             /* this.dt[k-1] = int_dp;  */
                 this.dt.push(dp);            
            }
            for(let l=0; l<7; l++)
            {
              document.write(this.dt[l].toString());
            }
            break;
            
        }
      //document.write(allTextLines[0]);
      //alert(this.csvData);
    
    }
    
     
    onFileSelect(input: HTMLInputElement){

      const files = input.files;

      var content = this.csvData;

      if (files && files.length){
        
        const filesToRead = files[0];

        const fileReader = new FileReader();

        fileReader.onload = this.onFileLoad;

        fileReader.readAsText(filesToRead, "UTF-8");

      }
      
    }

  @ViewChild('myCanvas')
  public canvas: ElementRef;
  public context: CanvasRenderingContext2D;
  public chartType: string = 'line';
  public chartData: any[];
  public chartLabels: any[];
  public chartColors: any[];
  public chartOptions: any;

  ngOnInit() {

     this.chartData = [{
      data: this.dt,
      label: 'Anthracnose',
      fill: false
    }];
    this.chartLabels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July'];


    this.chartColors = [{
      backgroundColor: 'rgba(0, 0, 0, 0.2)',
         borderColor: 'rgba(0, 0, 0, 1)'
    }];
    this.chartOptions = {
      scales: {
        yAxes: [{
          ticks: {
            beginAtZero: true,
            stepSize: 1
          }
        }]
      },
      
    }
  };

}
