import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { AdvertiseComponent } from './advertise/advertise.component';
import { LanguageComponent } from './language/language.component';
import { AppRoutingModule } from './app-routing.module';



@NgModule({
  declarations: [ AppComponent,AdvertiseComponent,LanguageComponent ],
  imports: [ BrowserModule,AppRoutingModule ],
  providers: [ ],
  bootstrap: [ AppComponent ]
})
export class AppModule { 
  constructor(){
    console.log("I ma module");
  }

  
  }

